<?php
	include('../php/conexion.php');
	include('../php/get.php');
	
	session_start();
	conectar();
	$user = $_SESSION['sc001'];
	$tipo = $_SESSION['sc002'];
	$clave = $_SESSION['sc003'];
	echo '<input id="user_log" type="hidden" value="'.$user.'" />'; // linea para chat
	
	if( !validaSesion($user,$clave) )
		header ("Location: ../index.php");
			
	desconectar();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo getTitulo(); ?></title>
     
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php echo getLibreriascss()?>

  </head>
  <body class="hold-transition skin-blue sidebar-mini">
  
    <div class="wrapper">
      <?php echo getHeader(); ?>
      <?php echo getMainMenu(); ?>
      <!--Slider-->
      <div class="content-wrapper">
          <div class="row" style="padding:0px 0px 0px 15px;">
            <div class="col-md-14" style="width:100%;">
              <div class="box box-solid">
                <div class="box-body" style="padding:0px 0px 0px 0px;">
                  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators" >
                      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                      <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                      <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                      <li data-target="#carousel-example-generic" data-slide-to="3" class=""></li>
                    </ol>
                    <div class="carousel-inner">
                      <div class="item active">
                        <img src="../imagenes/slider/fon2.jpg" alt="First slide">
                        <div class="carousel-caption">
                          First Slide
                        </div>
                      </div>
                      
                    </div>
                    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                      <span class="fa fa-angle-left"></span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                      <span class="fa fa-angle-right"></span>
                    </a>
                  </div>
                </div>
              </div>
            </div>               	      
              <!-- Main content -->
              <section class="content" style="background:#CCC;">
              
                    <div id="algos">algo</div>
                    
              </section>
        </div>
    </div>
    
 	<footer class="main-footer">
        <?php 
			echo getFooter();
			
		?>
	</footer>    
	
  <script src="../librerias/menu/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    
    
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
    <script>  
      $.widget.bridge("uibutton", $.ui.button);
    </script>
  <script src="../librerias/menu/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../js/chat_jquery.js"></script>
    <script type="text/javascript">jQuery.noConflict();</script>
  <script type="text/javascript" src="../js/chat_emoticons.js"></script>
    <script type="text/javascript" src="../js/chat.js"></script>   
  <script src="../librerias/menu/dist/js/app.min.js"></script>
  <script src="../js/imagen_usuario.js"></script>


	<script src="../js/main.js"></script>

  </body>
</html>
