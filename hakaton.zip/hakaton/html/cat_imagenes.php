<?php
	include('../php/conexion.php');
	include('../php/get.php');

	session_start();
	conectar();
	$user = $_SESSION['sc001'];
	$tipo = $_SESSION['sc002'];
	$clave = $_SESSION['sc003'];
	
	if( !validaSesion($user,$clave) )
		header ("Location: ../index.php");
	
	desconectar();
	echo '<input id="user_log" type="hidden" value="'.$user.'" />'; // linea para chat
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo getTitulo(); ?></title>
     
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php echo getLibreriascss()?>	

    <link href="http://mondeca.com/index.php/en/component/search/?Itemid=752&amp;format=opensearch" rel="search" title="Search Mondeca" type="application/opensearchdescription+xml"/>
	<link rel="stylesheet" href="/templates/t3_bs3_blank/local/css/themes/mondeca/A.bootstrap.css.pagespeed.cf.j9DSsuA2DQ.css" type="text/css"/>
	<link rel="stylesheet" href="/templates/A.system,,_css,,_system.css+t3_bs3_blank,,_local,,_css,,_themes,,_mondeca,,_template.css+t3_bs3_blank,,_local,,_css,,_themes,,_mondeca,,_megamenu.css+t3_bs3_blank,,_fonts,,_font-awesome,,_css,,_font-awesome.min.css+t3_bs3_blank,,_css,,_fontloader.css+t3_bs3_blank,,_fonts,,_templategothic,,_css,,_templategothic.css,Mcc.RfbYrHFrDr.css.pagespeed.cf.zmUEHjlLP4.css" type="text/css"/>

	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:500,400italic,100,300,500italic,300italic,400,200" type="text/css"/>
	<link rel="stylesheet" href="http://mondeca.com/media/A.coalawebcontact,,_components,,_contact,,_themes,,_light-clean,,_css,,_cw-mod-contact-light-clean.css+mod_languages,,_css,,_template.css,Mcc.ITWPYea8a9.css.pagespeed.cf.Skmb_VQg_v.css" type="text/css"/>
  
	<script src="/media/jui/js/jquery.min.js.pagespeed.jm.iDyG3vc4gw.js" type="text/javascript"></script>
	<script src="/media,_jui,_js,_jquery-noconflict.js+media,_jui,_js,_jquery-migrate.min.js+media,_system,_js,_caption.js+plugins,_system,_t3,_base-bs3,_bootstrap,_js,_bootstrap.js+plugins,_system,_t3,_base-bs3,_js,_jquery.tap.min.js+plugins,_system,_t3,_base-bs3,_js,_script.js+plugins,_system,_t3,_base-bs3,_js,_menu.js+templates,_t3_bs3_blank,_js,_fontloader.js+templates,_t3_bs3_blank,_js,_script.js.pagespeed.jc.Scz5zmL3X7.js"></script><script>eval(mod_pagespeed_VEShUZnb9g);</script>
	<script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js" type="text/javascript"></script>
	<script src="/plugins,_system,_t3,_base-bs3,_js,_nav-collapse.js+media,_system,_js,_mootools-core.js.pagespeed.jc.TkFqfRKiy-.js"></script><script>eval(mod_pagespeed_ZlfQYd6O1_);</script>
	<script src="/media/system/js/core.js+punycode.js+validate.js.pagespeed.jc.YArYSgACVn.js"></script><script>eval(mod_pagespeed_j_j96zFpqz);</script>
	<script type="text/javascript">jQuery(window).on('load',function(){new JCaption('img.caption');});jQuery(document).ready(function(){jQuery('.hasTooltip').tooltip({"html":true,"container":"body"});});;</script>
	<script type="text/javascript">(function(){Joomla.JText.load({"JLIB_FORM_FIELD_INVALID":"Invalid field:&#160"});})();</script>

	<!-- META FOR IOS & HANDHELD -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<style type="text/stylesheet">@-webkit-viewport   { width: device-width; }@-moz-viewport      { width: device-width; }@-ms-viewport       { width: device-width; }@-o-viewport        { width: device-width; }@viewport           { width: device-width; }</style>
	<script type="text/javascript">
	//<![CDATA[
	if(navigator.userAgent.match(/IEMobile\/10\.0/)){var msViewportStyle=document.createElement("style");msViewportStyle.appendChild(document.createTextNode("@-ms-viewport{width:auto!important}"));document.getElementsByTagName("head")[0].appendChild(msViewportStyle);}
	//]]></script>
	<meta name="HandheldFriendly" content="true"/>
	<meta name="apple-mobile-web-app-capable" content="YES"/>

	<script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create','UA-17663461-1','auto');ga('send','pageview');</script>

	<meta name="google-site-verification" content="iD_X10CcCcgJfT4IZJ8Un-orddTOeuISR8CZ9R8VXFw"/>

	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.3.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/jquery.simpleWeather/3.0.2/jquery.simpleWeather.min.js"></script>
		<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=AIzaSyBVTKLztwVOGDuo1qGsjHzdY7wXRcKbAVI"> </script>
		<script>jQuery(document).ready(function($){var weatheron=0;$('#weatherbutton').on('click',function(){weatheron=1-weatheron;ga('send','event','button','click','weather');if(weatheron){lng=$('#lng')[0].innerHTML;lat=$('#lat')[0].innerHTML;loadWeather(lat+','+lng);$('#weatherbutton').html('Hide weather');$('#weatherbutton').css('color','white');}else{$('#weather').html('');$('#weatherbutton').html('Show weather');$('#weatherbutton').css('color','white');}});function loadWeather(location,woeid){$.simpleWeather({location:location,woeid:woeid,unit:'c',success:function(weather){html='<h2><i class="icon-'+weather.code+'"></i> '+weather.temp+'&deg;'+weather.units.temp+'</h2>';html+='<ul><li>'+weather.city+', '+weather.region+'</li>';html+='<li class="currently">'+weather.currently+'</li>';html+='<li>'+weather.wind.direction+' '+weather.wind.speed+' '+weather.units.speed+'</li></ul>';$("#weather").html(html);},error:function(error){$("#weather").html('<p>'+error+'</p>');}});}});</script>
		<script>function load(){if(GBrowserIsCompatible()){var map=new GMap2(document.getElementById("map"));map.addControl(new GSmallMapControl());map.addControl(new GMapTypeControl());var center=new GLatLng(20.6737778,-103.4054542);map.setCenter(center,4);geocoder=new GClientGeocoder();var marker=new GMarker(center,{draggable:true});map.addOverlay(marker);document.getElementById("lat").innerHTML=center.lat().toFixed(5);document.getElementById("lng").innerHTML=center.lng().toFixed(5);GEvent.addListener(map,"dragstart",function(){document.getElementById("weather").innerHTML="";document.getElementById("weatherbutton").innerHTML="Show weather";});GEvent.addListener(marker,"dragend",function(){ga('send','event','map','drag/move','map');var point=marker.getPoint();map.panTo(point);document.getElementById("lat").innerHTML=point.lat().toFixed(5);document.getElementById("lng").innerHTML=point.lng().toFixed(5);});GEvent.addListener(marker,"dragstart",function(){document.getElementById("weather").innerHTML="";document.getElementById("weatherbutton").innerHTML="Show weather";});GEvent.addListener(map,"moveend",function(){ga('send','event','map','drag/move','map');map.clearOverlays();var center=map.getCenter();var marker=new GMarker(center,{draggable:true});map.addOverlay(marker);document.getElementById("lat").innerHTML=center.lat().toFixed(5);document.getElementById("lng").innerHTML=center.lng().toFixed(5);GEvent.addListener(marker,"dragend",function(){ga('send','event','map','drag/move','map');var point=marker.getPoint();map.panTo(point);document.getElementById("lat").innerHTML=point.lat().toFixed(5);document.getElementById("lng").innerHTML=point.lng().toFixed(5);});});}}function showAddress(address){var map=new GMap2(document.getElementById("map"));map.addControl(new GSmallMapControl());map.addControl(new GMapTypeControl());if(geocoder){geocoder.getLatLng(address,function(point){if(!point){alert(address+" not found");}else{document.getElementById("lat").innerHTML=point.lat().toFixed(5);document.getElementById("lng").innerHTML=point.lng().toFixed(5);map.clearOverlays()
		map.setCenter(point,14);var marker=new GMarker(point,{draggable:true});map.addOverlay(marker);GEvent.addListener(marker,"dragend",function(){var pt=marker.getPoint();map.panTo(pt);document.getElementById("lat").innerHTML=pt.lat().toFixed(5);document.getElementById("lng").innerHTML=pt.lng().toFixed(5);});GEvent.addListener(map,"moveend",function(){map.clearOverlays();var center=map.getCenter();var marker=new GMarker(center,{draggable:true});map.addOverlay(marker);document.getElementById("lat").innerHTML=center.lat().toFixed(5);document.getElementById("lng").innerHTML=center.lng().toFixed(5);GEvent.addListener(marker,"dragend",function(){var pt=marker.getPoint();map.panTo(pt);document.getElementById("lat").innerHTML=pt.lat().toFixed(5);document.getElementById("lng").innerHTML=pt.lng().toFixed(5);});GEvent.addListener(marker,"dragstart",function(){console.log('dragstart');document.getElementById("weather").innerHTML="";document.getElementById("weatherbutton").innerHTML="Show weather";});});}});}}if(window.attachEvent){window.attachEvent('onload',load);}else{if(window.onload){var curronload=window.onload;var newonload=function(){curronload();load();};window.onload=newonload;}else{window.onload=load;}}</script>
	<script>var formaddress=document.getElementById("address");formaddress.addEventListener("focusin",myFocusFunction);formaddress.addEventListener("focusout",myBlurFunction);function myFocusFunction(){document.getElementById("weather").innerHTML="";}function myBlurFunction(){document.getElementById("weather").innerHTML="";}</script>


  </head>
  <body class="hold-transition skin-blue sidebar-mini">
  
    <div class="wrapper">
	<!-- Menu arriba-->
      <?php echo getHeader(); ?>
    <!-- Menu izquierda--> 
      <?php echo getMainMenu(); ?>

      <div class="content-wrapper">
        <!-- Encabezado -->
        <section class="content-header">
          <h1> Subir imagenes </h1>
        </section>
        <!-- Boton agregar -->
        <section class="content">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Datos generales</h3>
            </div>
            <div class="box-body">
				
				<div id="lista_profes"></div>
            </div>
          </div>
        </section>
		
        <!-- Main content -->
        <section class="content">
          
        </section>
		<!-- Modal para agregar profesor -->
			  <div id="aprof_modal" class="modal fade" role="dialog">
				<div class="modal-dialog" id="modal_dialog_color">
					<!-- Modal content-->
					<div class="modal-content" id="modal_content_color">
					  <div class="modal-header" id="modal_header_color">
						<button type="button" id="close1" data-dismiss="modal">X</button>
						<h4 class="modal-title">Agregar administrador</h4>
					  </div>
					  <div class="modal-body" id="modal_body_color">
					  	<div id="modal_header" class="row">
						</div>
						<div class="row">
							<div class="col-md-12">
								<div id="ap_content"></div>
							</div>
                            <div class="col-md-12" style="text-align:center" id="imagen_log_prof_agre"> 
                                <img src="../imagenes/generales/gif/<?php echo getTituloImagenCargar() ?>" style="width:40px; height:40px;">
                            </div>
						  </div>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" id="boton_modal" onClick="agregaProfesor(2)">Agregar</button>
					  </div>
					</div>
				</div>
			</div>
		<!-- Modal para modificar profesores -->
			  <div id="aprof_modal_mod" class="modal fade" role="dialog">
				<div class="modal-dialog" id="modal_dialog_color">
					<!-- Modal content-->
					<div class="modal-content" id="modal_content_color">
					  <div class="modal-header" id="modal_header_color">
						<button type="button" id="close1" data-dismiss="modal">X</button>
						<h4 class="modal-title">Modificar administrador</h4>
					  </div>
					  <div class="modal-body" id="modal_body_color">
					  	<div id="modal_header" class="row">
						</div>
						<div class="row">
							<div class="col-md-12">
								<div id="ap_content1"></div>
							</div>
                            <div class="col-md-12" style="text-align:center" id="imagen_log_prof_mod"> 
                                <img src="../imagenes/generales/gif/<?php echo getTituloImagenCargar() ?>" style="width:40px; height:40px;">
                            </div>
						  </div>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" id="boton_modal" onClick="modificarProfesor(2)">Modificar</button>
					  </div>
					</div>
				</div>
			</div>
		<!--Modal información profesor -->
			  <div id="prof_info" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<!-- Modal content-->
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" id="close" data-dismiss="modal">X<!--&times;--></button>
						<h4 class="modal-title">Información del administrador</h4>
					  </div>
					  <div class="modal-body">
					  	<div id="profinfo_header" class="row">
						</div>
						<div class="row">
							<div class="col-md-6"></div><div class="col-md-6">
							</div>
						  </div>
					  </div>
					  <div class="modal-footer">
						<button type="button" id="boton_modal" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					  </div>
					</div>
				</div>
			</div>
      </div>
 
 	<footer class="main-footer">
		<?php 
			echo getFooter();
			echo getchats();
		?>
	</footer>

	<?php echo getLibreriasjs(); ?>
	<script src="../js/cat_imagenes.js"></script>

	


  </body>
</html>
