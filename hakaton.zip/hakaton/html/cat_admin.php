<?php
	include('../php/conexion.php');
	include('../php/get.php');

	session_start();
	conectar();
	$user = $_SESSION['sc001'];
	$tipo = $_SESSION['sc002'];
	$clave = $_SESSION['sc003'];
	
	if( !validaSesion($user,$clave) )
		header ("Location: ../index.php");
	
	desconectar();
	echo '<input id="user_log" type="hidden" value="'.$user.'" />'; // linea para chat
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo getTitulo(); ?></title>
     
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php echo getLibreriascss()?>
    
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
  
    <div class="wrapper">
	<!-- Menu arriba-->
      <?php echo getHeader(); ?>
    <!-- Menu izquierda--> 
      <?php echo getMainMenu(); ?>

      <div class="content-wrapper">
        <!-- Encabezado -->
        <section class="content-header">
          <h1> Catálogo de administradores </h1>
        </section>
        <!-- Boton agregar -->
        <section class="content">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Datos generales</h3>
            </div>
            <div class="box-body">
				<a href="javascript:agregaProfesor(1);" class="btn btn-sm btn-app">
                    <span class="badge"><i class="fa fa-plus"></i></span>
                    <i class="fa  fa-user-secret"></i> Agregar
                  </a>
				<div id="lista_profes"></div>
            </div>
          </div>
        </section>
		
        <!-- Main content -->
        <section class="content">
          
        </section>
		<!-- Modal para agregar profesor -->
			  <div id="aprof_modal" class="modal fade" role="dialog">
				<div class="modal-dialog" id="modal_dialog_color">
					<!-- Modal content-->
					<div class="modal-content" id="modal_content_color">
					  <div class="modal-header" id="modal_header_color">
						<button type="button" id="close1" data-dismiss="modal">X</button>
						<h4 class="modal-title">Agregar administrador</h4>
					  </div>
					  <div class="modal-body" id="modal_body_color">
					  	<div id="modal_header" class="row">
						</div>
						<div class="row">
							<div class="col-md-12">
								<div id="ap_content"></div>
							</div>
                            <div class="col-md-12" style="text-align:center" id="imagen_log_prof_agre"> 
                                <img src="../imagenes/generales/gif/<?php echo getTituloImagenCargar() ?>" style="width:40px; height:40px;">
                            </div>
						  </div>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" id="boton_modal" onClick="agregaProfesor(2)">Agregar</button>
					  </div>
					</div>
				</div>
			</div>
		<!-- Modal para modificar profesores -->
			  <div id="aprof_modal_mod" class="modal fade" role="dialog">
				<div class="modal-dialog" id="modal_dialog_color">
					<!-- Modal content-->
					<div class="modal-content" id="modal_content_color">
					  <div class="modal-header" id="modal_header_color">
						<button type="button" id="close1" data-dismiss="modal">X</button>
						<h4 class="modal-title">Modificar administrador</h4>
					  </div>
					  <div class="modal-body" id="modal_body_color">
					  	<div id="modal_header" class="row">
						</div>
						<div class="row">
							<div class="col-md-12">
								<div id="ap_content1"></div>
							</div>
                            <div class="col-md-12" style="text-align:center" id="imagen_log_prof_mod"> 
                                <img src="../imagenes/generales/gif/<?php echo getTituloImagenCargar() ?>" style="width:40px; height:40px;">
                            </div>
						  </div>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" id="boton_modal" onClick="modificarProfesor(2)">Modificar</button>
					  </div>
					</div>
				</div>
			</div>
		<!--Modal información profesor -->
			  <div id="prof_info" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<!-- Modal content-->
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" id="close" data-dismiss="modal">X<!--&times;--></button>
						<h4 class="modal-title">Información del administrador</h4>
					  </div>
					  <div class="modal-body">
					  	<div id="profinfo_header" class="row">
						</div>
						<div class="row">
							<div class="col-md-6"></div><div class="col-md-6">
							</div>
						  </div>
					  </div>
					  <div class="modal-footer">
						<button type="button" id="boton_modal" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					  </div>
					</div>
				</div>
			</div>
      </div>
 
 	<footer class="main-footer">
		<?php 
			echo getFooter();
			//echo getchats();
		?>
	</footer>

	<?php echo getLibreriasjs(); ?>
	<script src="../js/cat_admin.js"></script>

  </body>
</html>
