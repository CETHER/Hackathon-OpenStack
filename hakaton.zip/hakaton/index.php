<?php
	include("php/conexion.php");
	include('php/get.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>  <?php echo getSiglasIndex();?>  </title>
	<!-- meta -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!--<meta name="description" content="Lucy is the best Responsive App Landing Page designed with Bootstrap 3, HTML5 and CSS3. You can use this Responsive  App Landing Page for any kinds of app and game. Amazing design, creative layout and easily customizable.">-->
	<meta name="keywords" content="Bootstrap, Responsive, App Landing Page">
	<meta name="author" content="ThemeWagon">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 

	<!--favicon-->
	<link rel="shortcut icon" href="imagenes/generales/favicon/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="imagenes/generales/favicon/favicon.ico" type="image/x-icon">
	<link rel="icon" href="imagenes/generales/favicon/favicon.ico" type="image/x-icon">
    <!-- Stylesheets -->
	<link rel="stylesheet" href="librerias/menu_index/libs/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="librerias/ionicons/css/ionicons.min.css">
	<link rel="stylesheet" href="librerias/menu_index/css/owl.carousel.css">
	<link rel="stylesheet" href="librerias/menu_index/css/animate.css">
	<link rel="stylesheet" href="librerias/menu_index/css/style.css">
	<!-- Google Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic|Roboto+Condensed:300italic,400italic,700italic,400,300,700' rel='stylesheet' type='text/css'>
	<script src="librerias/menu_index/js/modernizr.custom.js"></script>
    <!-- Libreria para filtrar listas -->
	<script type="text/javascript" src="librerias/TableFilter/tablefilter_all.js"></script>
	<link type="text/css" href="librerias/TableFilter/filtergrid.css" rel="stylesheet" />

	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="librerias/css/ventana_modal.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body id="home">

	<!-- ****************************** Preloader ************************** -->
	<div id="preloader"></div>

	<!-- ****************************** Sidebar ************************** -->
	<nav id="sidebar-wrapper">
		<a id="menu-close" href="#" class="close-btn toggle">CERRAR <i class="ion-log-in"></i></a>
	    <ul class="sidebar-nav">
		    <li><a href="#home">INICIO</a></li>
			<!--
            <li><a href="#video">DEMO</a></li>
			<li><a href="#bigfeatures">EXPERIENCIA DE USUARIOS</a></li>
			<li><a href="#features">SERVICIOS</a></li>
			<li><a href="#features-left-image">INFORMACIÓN</a></li>
			<li><a href="#gallery">DISEÑO E INTERFAZ</a></li>
			<li><a href="#testimonial">TESTIMONIO</a></li>
			<li><a href="#team">DESARROLLADORES</a></li>
            <li><a href="#pricing">Pricing</a></li>
			<li><a href="#subscribe">Subscribe</a></li>
			<li><a href="#contact">Contact us</a></li>
            -->
	    </ul>
	</nav>
	
	<!-- ****************************** Header ************************** -->
	<header class="sticky" id="header">
		<div class="container">
			<div class="row" id="logo_menu">
				<div class="col-xs-6"><a class="logo" href="" style="font-size:37px;"><?php echo getSiglasIndex();?></a></div>
				<div class="col-xs-6"><a id="menu-toggle" href="#" class="toggle" role="button" title="Menú" data-toggle="tooltip" data-placement="left"><i class="ion-navicon"></i></a></div>
			</div>
		</div>
	</header>

	<!-- ****************************** BANER E IMAGEN PRINCIPAL ************************** -->
	<section id="banner" >		
		<div class="banner-overlay"></div>
		<div class="container">
			<a class="slidedown wow animated zoomIn" data-wow-delay="2s" href="#video"><i class="ion-ios-download-outline"></i></a>
			<div class="row">
				<div class="col-md-6">
					<div class="headings">
						<h2 class="wow animated fadeInDown" style="color:#fff;">EASY UP... &nbsp; EASY SAVE </h2>
						<p class="wow animated fadeInLeft"><?php echo getNomCompleto();?></p>
				
						<a href="#" onClick="$('#prof_info').modal('show');" class="btn btn-store wow animated bounceInUp">
							<i class="ion-person"></i>
							<span>Iniciar</span><br/>
							 Sesión
						</a>
						<br />
						<a href="#" onClick="$('#aprof_modal').modal('show');" class="btn btn-store wow animated bounceInUp">
							<i class="ion-person"></i>
							<span>Iniciar</span><br/>
							 Registro
						</a>

					</div>
				</div>
				<div class="col-md-6 hidden-xs hidden-sm">
					<div class="hand-container">
					<img class="iphone-hand img_res wow animated bounceInUp" data-wow-duration="1.2s" src="imagenes/fondos/fon2.jpg" alt="">
					<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- ****************************** INFORMACIÓN ************************** -->
	<!--
    <section id="features-left-image" class="block">
		<div class="container">
			
			<div class="row">
				<div class="col-sm-6 wow fadeInLeft animated">
					<div class="phone-image">
						<img class="img-responsive" src="imagenes/fondos/2-iphone-left.png" alt="">
					</div>
				</div>

				<div class="col-sm-6 wow fadeInRight animated">
					
					<div class="title-box text-center">
						<h1 class="block-title wow animated zoomIn">
							INFORMACIÓN
						</h1>
					</div>
					
					<div class="row">
						<div class="col-md-12">
							<p style="text-align:justify;">Es un sistema en línea que brinda apoyo a cada una de las diferentes áreas escolares, el cual permite realizar múltiples tareas facilitando el trabajo, la comunicación y la eficiencia al momento de realizar cualquier cosa.</p>
							<ul>
								<li><i class="ion-ios-paper-outline" style="color:#3c8dbc"></i> Almacenar y acceder a información</li>
								<li><i class="ion-stats-bars" style="color:#3c8dbc"></i> Estadísticas actualizadas </li>
								<li><i class="ion-ios-bookmarks-outline" style="color:#3c8dbc"></i> Cursos de manera virtual </li>
								<li><i class="ion-university" style="color:#3c8dbc"></i> Seguimiento a egresados </li>
								<li><i class="ion-person" style="color:#3c8dbc"></i> Seguimiento de estudiantes </li>
                                <ul>
									<li><i class="ion-ios-people" style="color:#3c8dbc"></i> Tutorías </li>
                                    <li><i class="ion-ios-americanfootball" style="color:#3c8dbc"></i> Actividades deportivas </li>
                                    <li><i class="ion-person-stalker" style="color:#3c8dbc"></i> Orientación educativa </li>
                                </ul>
								<li><i class="ion-grid" style="color:#3c8dbc"></i> Entre otros. </li>
							</ul>
						</div>
					</div>
				</div>

			</div>
			
		</div>
	</section>
	-->
	<!-- ****************************** USUARIOS ************************** -->
    <!--
    <section id="bigfeatures" class="img-block-3col block">
        
                <div class="container">
        
                    <div class="title-box">
                        <h1 class="block-title wow animated zoomIn">
                            EXPERIENCIA DE USUARIOS
                        </h1>
                    </div>
        
                    <div class="row">
                        <div class="col-sm-4">
                            <ul class="item-list-right item-list-big" style="margin-top:100px;">
                                <li class="wow fadeInLeft animated"> <i class="ion-android-laptop"></i>
                                    <h3>DISEÑO RESPONSIVO</h3>
                                    <p>Con este tipo de diseño, podras desde cualquier dispositivo sea de escritorio o dispositivo móvil acceder a toda la información de manera clara facilitando al usuario entender lo que le interesa leer.</p>
                                </li>
                                <li class="wow fadeInLeft animated"> <i class="ion-android-color-palette"></i>
                                    <h3>COLORES</h3>
                                    <p>Los colores utilizados facilitan distinguir claramente la información al igual que delimita cada sección expuesta.</p>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-4 col-sm-push-4">
                            <ul class="item-list-left item-list-big" style="margin-top:100px;">
                                <li class="wow fadeInRight animated"> <i class="ion-cube"></i>
                                    <h3>INTERACTIVIDAD</h3>
                                    <p>Tiene una interfaz agradable y dinámica que permite navegar con gran facilidad, encontrando lo que necesitas de manera rápida.</p>
                                </li>
                                <li class="wow fadeInRight animated"> <i class="ion-checkmark-round"></i>
                                    <h3>ALGO</h3>
                                    <p>Descipción.</p>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-4 col-sm-pull-4 text-center">
                            <div class="animation-box wow bounceIn animated">
                                <img class="highlight-left wow animated" src="imagenes/fondos/spark.png" height="192" width="48" alt=""> 
                                <img class="highlight-right wow animated" src="imagenes/fondos/spark.png" height="192" width="48" alt="">
                                <img class="screen" src="imagenes/fondos/iphone.png" alt="" height="581" width="300">
                            </div>
                        </div>
                    </div>
                </div>
	</section>
    -->
	<!-- ****************************** SERVICIOS ************************** -->
	<!--
    <section id="features" class="block">
		<div class="container">
			<div class="title-box">
				<h1 class="block-title wow animated zoomIn">
					SERVICIOS
				</h1>
			</div>
			
			<div class="row">
				<div class="col-sm-6 col-md-4">
					<div class="feature-box wow animated flipInX animated">
						<i class="ion-person-stalker"></i>
						<h2>ACADÉMICOS</h2>
						<p>Permite a docentes tener un registro detallado al día de cada uno de sus grupos así como de cada uno de sus estudiantes.</p>
					</div>
				</div>
				<div class="col-sm-6 col-md-4">
					<div class="feature-box wow animated flipInX animated">
						<i class="ion-ios-bookmarks-outline"></i>
						<h2>CURSOS</h2>
						<p>Te permiten complementar tus clases de manera virtual, con diversos materiales de apoyo teniendo consultas en tiempo real.</p>
					</div>
				</div>
				<div class="col-sm-6 col-md-4">
					<div class="feature-box wow animated flipInX animated">
						<i class="ion-university"></i>
						<h2>EGRESADOS</h2>
						<p>Brinda una comunicación constante con cada uno de los egresados, teniendo información actualizada y precisa.</p>
					</div>
				</div>
				<div class="col-sm-6 col-md-4">
					<div class="feature-box wow animated flipInX animated">
						<i class="ion-ios-people"></i>
						<h2>TUTORÍAS</h2>
						<p>Mantiene informada a las áreas involucradas con el seguimiento tutorial de manera grupal e individual, así mismo a cada padre de familia.</p>
					</div>
				</div>
				<div class="col-sm-6 col-md-4">
					<div class="feature-box wow animated flipInX animated">
						<i class="ion-stats-bars"></i>
						<h2>ESTADÍSTICAS</h2>
						<p>Permite a los directivos, administrativos y docentes realizar los registros de los estudiantes brindándoles estadísticas en tiempo real de la situación de cada estudiante .</p>
					</div>
				</div>
				<div class="col-sm-6 col-md-4">
					<div class="feature-box wow animated flipInX animated">
						<i class="ion-ios-football"></i>
						<h2>DEPORTES</h2>
						<p>Realiza una detallada descripción física y deportiva de cada estudiante al igual que su alimentación.</p>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</section>
    -->
	<!-- ****************************** DEMO ************************** -->
	<!--
    <section id="video" class="block">
		<div class="container">
			
			<div class="title-box">
				<h1 class="block-title wow animated zoomIn">
					DEMO
				</h1>
			</div>

			<div class="row">
				<div class="col-sm-offset-2 col-sm-8 wow animated bounceInUp">
					
					<div class="embed-responsive embed-responsive-16by9">
					  <iframe class="embed-responsive-item async-iframe" data-src="http://player.vimeo.com/video/718489?title=0&amp;byline=0&amp;portrait=0&amp;color=41a1e1" width="560" height="315" allowfullscreen></iframe>
					</div>
					<p class="text-center italic">
						<strong>Descripción.</strong>
					</p>
				</div>
			</div>
		</div>
	</section>
	-->
	<!-- ****************************** CALIDAD ************************** -->
	<!--
    <section id="features-right-image" class="block">
		<div class="container">
			
			<div class="row">
				<div class="col-sm-6 wow fadeInLeft animated">
					<div class="title-box text-center">
						<h1 class="block-title wow animated zoomIn">
							CALIDAD
						</h1>
					</div>
					
					<div class="row">
						<div class="col-md-12">
							<p class="mb50" style="text-align:justify;">
                            Sin duda alguna el reto de cualquier sistema educativo del país es brindar una educación de calidad, ya que es una de las principales bases del ser humano.<br/>
                            Cada día que pasa la exigencia y el compromiso de las instituciones educativas es mayor, el extender las fronteras del conocimiento se a vuelto un reto, por ello el trabajo que se tiene que realizar es muy arduo y extenso, donde la virtualización es fundamental para la enseñanza-aprendizaje.<br/>
                            Atendiendo a las necesidades actuales de la educación se realiza un sistema en línea que facilite el trabajo administrativo-académico, dando herramientas de trabajo para ofrecer un mejor servicio a las diferentes comunidades del país.
                            </p>
						</div>
					</div>
				</div>

				<div class="col-sm-6 wow fadeInRight animated">	
					<div class="phone-image">
						<img class="img-responsive" src="imagenes/fondos/2-iphone-right.png" alt="">
					</div>
				</div>
			</div>
			
		</div>
	</section>
	-->
	<!-- ****************************** GALERIA ************************** -->
	<!--
    <section id="gallery" class="block">
		<div class="container">

			<div class="title-box">
				<h1 class="block-title wow animated zoomIn">
					DISEÑO E INTERFAZ AMIGABLE
				</h1>
			</div>

			<div class="row">
				<div class="col-xs-12">
					<div id="screenshots" class="owl-carousel owl-theme">
					  <a href="img/screenshots/1.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/1.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					  <a href="img/screenshots/2.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/2.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					  <a href="img/screenshots/3.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/1.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					  <a href="img/screenshots/4.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/4.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					  <a href="img/screenshots/1.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/1.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					  <a href="img/screenshots/2.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/2.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					  <a href="img/screenshots/3.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/1.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					  <a href="img/screenshots/4.jpg" class="item" data-lightbox-gallery="screenshots">
					  	<img src="imagenes/fondos/4.jpg" class="img_res wow animated zoomIn" alt="">
					  </a>
					</div>
					 <div class="customNavigation">
					  <a class="btn prev gallery-nav wow animated bounceInLeft"><i class="ion-ios-arrow-left"></i></a> 
					  <a class="btn next gallery-nav wow animated bounceInRight"><i class="ion-ios-arrow-right"></i></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	-->
	<!-- ****************************** TESTIMONIO ************************** -->
	<!--
    <section id="testimonial" class="block">
		<div class="banner-overlay"></div>

		<div class="container">		
			<div id="review" class="owl-carousel owl-theme wow animated bounceInUp">
				<div class="item">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<div class="client-pic"><img class="img_res" src="imagenes/admin/nofotoh.jpg" alt=""></div>
							<p class="review-star">
								<i class="ion-star"></i>
								<i class="ion-star"></i>
								<i class="ion-star"></i>
								<i class="ion-star"></i>
                                <i class="ion-star"></i>
								<i class="ion-star-outline"></i>
							</p>
							<p class="review-desc">
								Testimonio.
							</p>
							<p class="client-name">
								Mtro. José Manuel Delgadillo Pulido
							</p>
							<p class="client designation">Escuela Preparatoria Regional de El Salto.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	-->
	<!-- ****************************** EXPERTOS ************************** -->
	<!--
    <section id="team" class="block">
		<div class="container">
			<div class="title-box">
				<h1 class="block-title wow animated zoomIn">
					DESARROLLADORES
				</h1>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-6 col-md-offset-1point5">
					<div class="team-member wow animated fadeIn" data-wow-delay="0.3s">
						<div class="border-img">
							<img src="imagenes/admin/nofotoh.jpg" class="img_res team-pic" alt="">
							<div class="border"></div>
						</div>
						<h2 class="wow animated fadeInDown" data-wow-delay="0.7s">Salvador Calvillo</h2>
						<p class="wow animated fadeIn" data-wow-delay="0.7s">Ingeniero en Computación, Maestría en Tecnologías de Información .</p>
						<ul class="team-social">
							<li class="wow animated fadeInLeft facebook"><a href="#"><i class="ion-social-facebook"></i></a></li>
							<li class="wow animated fadeInLeft linkedin"><a href="#"><i class="ion-social-linkedin"></i></a></li>
							<li class="wow animated fadeInRight googleplus"><a href="#"><i class="ion-social-googleplus-outline"></i></a></li>
							<li class="wow animated fadeInRight github"><a href="#"><i class="ion-social-github"></i></a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-4 col-sm-6">
					<div class="team-member wow animated fadeIn" data-wow-delay="0.3s">
						<div class="border-img">
							<img src="imagenes/admin/nofotoh.jpg" class="img_res team-pic" alt="">
							<div class="border"></div>
						</div>
						<h2 class="wow animated fadeInDown" data-wow-delay="0.7s">J. Jesús Salas</h2>
						<p class="wow animated fadeIn" data-wow-delay="0.7s">Licenciado en Informática, Maestría en Habilidades para el Aprendizaje.</p>
						<ul class="team-social">
							<li class="wow animated fadeInLeft facebook"><a href="#"><i class="ion-social-facebook"></i></a></li>
							<li class="wow animated fadeInLeft linkedin"><a href="#"><i class="ion-social-linkedin"></i></a></li>
							<li class="wow animated fadeInRight googleplus"><a href="#"><i class="ion-social-googleplus-outline"></i></a></li>
							<li class="wow animated fadeInRight github"><a href="#"><i class="ion-social-github"></i></a></li>
						</ul>
					</div>
				</div>

			</div>
		</div>
	</section>
	-->
	<!-- ****************************** Pricing section ************************** -->
    <!--
        <section id="pricing" class="block">
            <div class="banner-overlay bg-color-grad"></div>
            <div class="container">
                <div class="title-box">
                    <h1 class="block-title title-light wow animated zoomIn">
                        <span class="bb-top-left"></span>
                        <span class="bb-bottom-left"></span>
                        Affordable Packages
                        <span class="bb-top-right"></span>
                        <span class="bb-bottom-right"></span>
                    </h1>
                </div>
                <div class="row">
                    <div class="col-md-offset-2 col-md-8">
                        <ul class="pricing-table">
                            <li class="wow flipInY animated" style="visibility: visible;">
                                <h3>Standard</h3>
                                <span> $2.99 <small>per month</small> </span>
                                <ul class="benefits-list">
                                    <li>Responsive</li>
                                    <li>Documentation</li>
                                    <li class="not">Multiplatform</li>
                                    <li class="not">Video background</li>
                                    <li class="not">Support</li>
                                </ul>
                                <a href="#" target="_blank" class="buy"><i class="ion-ios-cart-outline"></i></a>
                            </li>
                            <li class="gold wow flipInY animated" data-wow-delay="0.4s" style="visibility: visible;-webkit-animation-delay: 0.4s; -moz-animation-delay: 0.4s; animation-delay: 0.4s;">
                                <div class="stamp"><i class="ion-android-star-outline"></i>Best choice</div>
                                <h3>Gold</h3>
                                <span> $7.99 <small>per month</small> </span>
                                <ul class="benefits-list">
                                    <li>Responsive</li>
                                    <li>Documentation</li>
                                    <li>Multiplatform</li>
                                    <li>Video background</li>
                                    <li>Support</li>
                                </ul>
                                <a href="#" target="_blank" class="buy"> <i class="ion-ios-cart-outline"></i></a>
                            </li>
                            <li class="silver wow flipInY animated" data-wow-delay="0.2s" style="visibility: visible;-webkit-animation-delay: 0.2s; -moz-animation-delay: 0.2s; animation-delay: 0.2s;">
                                <h3>Sliver</h3>
                                <span> $4.99 <small>per month</small> </span>
                                <ul class="benefits-list">
                                    <li>Responsive</li>
                                    <li>Documentation</li>
                                    <li>Multiplatform</li>
                                    <li class="not">Video background</li>
                                    <li class="not">Support</li>
                                </ul> 
                                <a href="#" target="_blank" class="buy"> <i class="ion-ios-cart-outline"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    -->
	
	<!-- ****************************** CONTACTANOS ************************** -->
    <!--
    <section id="contacto" class="block">
   		<div class="banner-overlay" style="background: rgba(255, 255, 255, 0.8)"></div>
			<div class="container">
				<div class="title-box">
					<h1 class="block-title wow animated zoomIn">
                        CONTACTANOS
					</h1>
				</div>
				<div class="row">
		
					<div class="col-sm-4 address wow fadeInLeft animated">
						<ul class="address-list">
							<li><i class="ion-location"></i> <span>Dirección <br>Número</span></li>
							<li><i class="ion-android-call"></i> <span> 00-00-00-00-00 </span></li>
							<li><i class="ion-email"></i> <span> dominio@gmail.com</span></li>
							<li><i class="ion-earth"></i> <span> www.siiaa.com.mx</span></li>
						</ul>
					</div>
					<div class="col-sm-8 mailbox wow fadeInRight animated">
						<form name="sentMessage" id="contactForm" novalidate>
	                        <div class="row">
	                            <div class="col-md-6">
	                                <div class="form-group">
	                                    <input type="text" class="form-control" placeholder="Your Name *" id="name" required>
	                                    <p class="help-block text-danger"></p>
	                                </div>
	                                <div class="form-group">
	                                    <input type="email" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
	                                    <p class="help-block text-danger"></p>
	                                </div>
	                                <div class="form-group">
	                                    <input type="text" class="form-control" placeholder="Your Subject *" id="subject" required data-validation-required-message="Please enter your phone number.">
	                                    <p class="help-block text-danger"></p>
	                                </div>
	                            </div>
	                            <div class="col-md-6">
	                                <div class="form-group">
	                                    <textarea class="form-control" placeholder="Your Message *" id="message" required data-validation-required-message="Please enter a message."></textarea>
	                                    <p class="help-block text-danger"></p>
	                                    <div id="success"></div>
		                                <button type="submit" class="polo-btn contact-submit"><i class="ion-paper-airplane"></i></button>
	                                </div>
	                            </div>
	                        </div>
	                        <div class="alert alert-danger error">Error!  E-mail must be valid and message must be longer than 1 character.</div>
	                        <div class="alert alert-success success">Your message has been sent successfully.</div>
	                    </form>
					</div>

				</div>
			</div>
			<div class="clearfix"></div>
	</section>
	-->
	<!-- ****************************** Footer ************************** -->
	<!--
    <section id="footer" class="block">
		<div class="container text-center">
			<div class="footer-logo">
				<h1>REDES  SOCIALES</h1>
			</div>
			<ul class="social-icons">
				<li class="wow animated fadeInLeft facebook"><a href="#"><i class="ion-social-facebook"></i></a></li>
				<li class="wow animated fadeInRight twitter"><a href="#"><i class="ion-social-twitter"></i></a>
				<li class="wow animated fadeInLeft linkedin"><a href="#"><i class="ion-social-linkedin"></i></a></li>
				<li class="wow animated fadeInRight googleplus"><a href="#"><i class="ion-social-googleplus-outline"></i></a></li>
				<li class="wow animated fadeInRight github"><a href="#"><i class="ion-social-github"></i></a>
			</ul>

			<div class="copyright">
				<div>© 2016 Todos los derechos reservados. | Sistema Integral de Información Académica y Administrativa. SIIAA</div>

			</div>
		</div>
	</section>
	-->
	<!-- ****************************** FLECHA ************************** -->
	<!--
    <a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Regresar al inicio de la página" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>
	-->
        <!--Modal iniciar sesión -->
        <div id="prof_info" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title">INICIAR SESIÓN</h4>
                  </div>
                  <div class="modal-body">
                    <div id="profinfo_header" class="row">
                      <div class="unido">
                          <div class="titulo"> ¡ Bienvenido !</div>
                          <div class="lockscreen-item">
                            <div class="imagen">
                              <img class="imagen" src="imagenes/admin/nofotoh.jpg" alt="User Image">
                            </div>
                            <div style="color:#0d3863;font-size:15px;"> Identificate </div>
                            <hr class="separador">
                            <form class="forminisesion" id="contactForm" action="#">
                              <div class="grupo">
                                <input type="text" id="user" class="form_input" placeholder="Usuario">
                                  <div class="btnicono"><i class="ion-navicon-round"></i></div>
                                  <hr class="dividir">
                                <input type="password" id="pass" class="form_input" placeholder="Contraseña">
                                  <!--<div class="btnicono"><i class="ion-lock-combination"></i><i class="ion-key"></i></div>-->
                                  <div class="btnicono"><i class="ion-android-lock"></i></div>
                                </div>
                            </form>
							<img src="imagenes/generales/gif/<?php echo getTituloImagenCargar() ?>" id="imagen_log" style="width:40px; height:40px;">
                            <br />
                            <div id="msj">Mensaje</div>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"></div><div class="col-md-6">
                        </div>
                      </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="boton_modal" class="btn btn-default" data-dismiss="modal" style="float:left;" onClick="$('#rec_pass').modal('show');">Recuperar contraseña</button>
                    
                    <button type="button" id="boton_modal" class="btn btn-default" onClick="validar()">Iniciar Sesión</button>
					<button type="button" id="boton_modal" class="btn btn-default" data-dismiss="modal" onClick="cancelar()">Cancelar</button>
                  </div>
                </div>
            </div>
        </div>
		<!--Modal ragregar usuario -->
		<div id="aprof_modal" class="modal fade" role="dialog">
				<div class="modal-dialog" id="modal_dialog_color">
					<!-- Modal content-->
					<div class="modal-content" id="modal_content_color">
					  <div class="modal-header" id="modal_header_color">
						<button type="button" id="close1" data-dismiss="modal">X</button>
						<h4 class="modal-title">Registro de usuarios</h4>
					  </div>
					  <div class="modal-body" id="modal_body_color">
					  	<div id="modal_header" class="row">
						</div>
						<div class="row">
							<div class="col-md-12">								
								<form role="form" id="contactForm2" action="#">
									<div class="col-md-12">
										<div id="apcod_form" class="form-group">
										  <label>Usuario:</label>
										  <input id="apcod" type="text" class="form-control" placeholder="Usuario...">
										</div>
										<div id="apnom_form" class="form-group">
										  <label>Contraseña:</label>
										  <input id="apnom" type="password" class="form-control" placeholder="Contraseña..."  maxlength="20">
										</div>
										<div id="apgen_form" class="form-group">
										  <label>Género: </label>
										  <select id="apgen" class="form-control">
											<option value="0">Seleccione...</option>
											<?php	
												global $mysqli;
												conectar();									
												$sql = "SELECT * FROM genero";
												$query = $mysqli->query($sql);
												while( $row = $query->fetch_row() )
														echo '<option value="'.$row[0].'">'.$row[1].'</option>';
												$query->close();
												desconectar();
											?>					
									 	  </select>
										</div>			
									</div>
									<div class="col-md-12">
										<div id="apmsj2" class="callout callout-danger"></div>
									</div>
								</form>

							</div>
                            <div class="col-md-12" style="text-align:center" id="imagen_log2"> 
                                <img src="imagenes/generales/gif/<?php echo getTituloImagenCargar() ?>" style="width:40px; height:40px;">
                            </div>
						  </div>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" id="boton_modal" onClick="agregar(1)">Agregar</button>
						<button type="button" id="boton_modal" class="btn btn-default" data-dismiss="modal" onClick="cancelar()">Cancelar</button>
					  </div>
					</div>
				</div>
			</div>
        <!--Modal recuperar contraseña -->
        <div id="rec_pass" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title">RESTABLECE TU CONTRASEÑA</h4>
                  </div>
                  <div class="modal-body">
                    <div id="profinfo_header" class="row">
                      <div class="unido">
                          <div class="titulo"> ¡ Bienvenido !</div>
                          <div class="lockscreen-item">
                            <div class="imagen" style="margin-top:-40px; margin-bottom:20px;">
                            <div style="background:#fff; width:100px; height:100px; margin-left:42%; margin-top:10%; border-radius:50%;"> <i class="ion-key" style="font-size:100px; color:#000;"></i> </div>
                            </div>
                            <div style="color:#0d3863; font-size:14px; width:97%;"> 
                            	<p>Para recuperar su contraseña, coloca tu código y tu dirección de correo electrónico.<br />
 								Si existe en la base de datos, apareceran nuevas instrucciones en el email que se te enviará para poder ingresar nuevamente al sistema 
                                </p>
                            </div>
                            <hr class="separador">
                            <div id="parte_pass">
                                <form class="forminisesion" id="contactForm1" action="#">
                                  <div class="grupo">
                                    <input type="text" id="prof" class="form_input" placeholder="Código" >
                                      <div class="btnicono"><i class="ion-navicon-round"></i></div>
                                      <hr class="dividir">
                                        <input type="text" id="correo" class="form_input" placeholder="Correo electrónico" >
                                      <div class="btnicono"><i class="ion-ios-email"></i></div>
                                    </div>
                                </form>
                            </div>
                            <hr class="separador">
                            
                            <div style="color:#0d3863; font-size:14px; width:97%;"> 
                            	<p>Si el correo no aparece en la bandeja de entrada, revisa en la los correos no deceados</p>
                            </div>
                            <img src="imagenes/generales/gif/cargando.gif" id="imagen_log1" style="width:40px; height:40px;">
                            <div id="msj_rec_pass_ok" style="color:#fff; background:#47B145; width:70%; height:auto; border-radius:5px; margin: 0 auto"></div>
                            <div id="msj_rec_pass_no" style="color:#fff; background:#F30; width:70%; height:auto; border-radius:5px; margin: 0 auto"></div>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"></div><div class="col-md-6">
                        </div>
                      </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="boton_modal" class="btn btn-default" onClick="rec_pass()">Recuperar</button>
					<button type="button" id="boton_modal" class="btn btn-default" data-dismiss="modal" onClick="cancelar()">Cancelar</button>
                  </div>
                </div>
            </div>
        </div>         
        

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="librerias/menu_index/libs/bootstrap/js/bootstrap.min.js"></script>
	<script src="librerias/menu_index/js/wow.min.js"></script>
	<script src="librerias/menu_index/js/owl.carousel.js"></script>
	<script src="librerias/menu_index/js/nivo-lightbox.min.js"></script>
	<script src="librerias/menu_index/js/smoothscroll.js"></script>
	<script src="librerias/menu_index/js/jquery.ajaxchimp.min.js"></script>
	<script src="librerias/menu_index/js/script.js"></script>
    <script src="librerias/menu/dist/js/app.min.js"></script>

  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <script src="js/login.js"></script>
  <script src="js/agregar_usuarios.js"></script>

</body>
</html>
