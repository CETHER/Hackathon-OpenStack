function limpiaMsjs(){
	$("#apmsj2").hide();
	$("#imagen_log2").hide();
	
	$("#apcod_form").removeClass("has-error");
	$("#apnom_form").removeClass("has-error");
	$("#apgen_form").removeClass("has-error");

}

function agregar(fun){
	if( fun == 1 ){
		limpiaMsjs();
		error=false;
		if( !$("#apcod").val() ){
			error = true;
			$("#apcod_form").addClass("has-error");
		}
		if( !$("#apnom").val() ){
			error = true;
			$("#apnom_form").addClass("has-error");
		}
		if( $("#apgen").val() == 0 ){
			error = true;
			$("#apgen_form").addClass("has-error");
		}
		if(error){
			$("#apmsj2").html('Debe llenar todos los datos correctamente.');
			$("#apmsj2").slideDown();
		}else{
			jQuery.ajax({
				type: "POST",
				url: "./php/cat_admin.php",
				data: {
					fun:2,
					fun2:2,
					cod:$("#apcod").val(),
					nom:$("#apnom").val(),
					gen:$("#apgen").val()
				},
				beforeSend: function(){
					//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
					
				},
				fail: function(){
						//$.unblockUI();
						alert("Se perdió la conexión...");
				},
				success: function(data, textStatus){
					$("#imagen_log2").show();
					dat = data.split('@|');
					if( dat[0] == '1' ){
						$("#imagen_log2").hide();
						$("#apmsj2").html(dat[1]);
						$("#apmsj2").slideDown();
						$("#apcod_form").addClass('has-error');
					}else{
						$("#aprof_modal").modal('hide');
						$('#contactForm2')[0].reset();
					}
					    
				}
					
			});
		}
	}else{}
}

