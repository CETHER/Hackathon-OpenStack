function showHide(){ 
	var oImageDiv = document.getElementById('subir_imagen_ventana') 
	oImageDiv.style.display = (oImageDiv.style.display == 'none')?'inline':'none' 
} 
function hiden(){ 
	var oImageDiv = document.getElementById('subir_imagen_ventana') 
	oImageDiv.style.display = (oImageDiv.style.display == 'none')?'inline':'none';	
} 

// scrip para subir imagen

$('#preview').hover(
    function() {
        $(this).find('a').fadeIn();
    }, function() {
        $(this).find('a').fadeOut();
    }
)
$('#file-select').on('click', function(e) {
     e.preventDefault();
    
    $('#file').click();
})

$('#file-select1').on('click', function(e) {
     e.preventDefault();
    
    $('#file').click();
})

$('input[type=file]').change(function() {
    var file = (this.files[0].name).toString();
    var reader = new FileReader();
    
   // $('#file-info').text('');
    //$('#file-info').text(file);
     reader.onload = function (e) {
         $('#preview img').attr('src', e.target.result);
	 }
     
     reader.readAsDataURL(this.files[0]);
});    

function subirImage(){
	$("input[name='file']").on("change", function(){
		var formData = new FormData($("#file-submit")[0]);
		var ruta = "../php/subir_imagenes.php";
		$.ajax({
			url: ruta,
			type: "POST",
			data: formData,
			contentType: false,
			processData: false,
			success: function(datos, textStatus)
			{
				if(datos != ''){
					$('#respuesta').html(datos);
					setTimeout(function(){$("#respuesta").addClass("hide"); }, 2000);
					//setTimeout(function(){ hiden(); }, 2000);
					if(datos == 'Imagen modificada exitosamente' || datos == 'Imagen guardada exitosamente'){
						setTimeout(function(){ location.reload(); }, 2000);
					}else{
						$('#respuesta').html('La imagen no se pudo modificar');
					}
				}else{
					$('#respuesta').html('Ingresa una imagen');
				}
			}
		});
	});
}
