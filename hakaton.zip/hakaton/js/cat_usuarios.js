$(document).ready(function(){
	$("#salir").click(function(){
		jQuery.post("../php/login.php", {
			fun:2
			}, function(data, textStatus){
				location.href="../index.php";
			}
		);
	});
	listaProfesores();
});

function listaProfesores(){
	jQuery.ajax({
		type: "POST",
		url: "../php/cat_usuarios.php",
		data:{
			fun:1
		},
		beforeSend: function(){
			//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
		},
		fail: function(){
			//$.unblockUI();
			alert("Se perdi� la conexi�n...");
		},
		success: function(data, textStatus){
			$("#lista_profes").html(data);
			var tabla_Props =  {   
				loader: true,
				loader_text: "Filtrando resultados...",
				help_instructions: false,
				btn_reset: true,
				col_0: "none",
				col_5: "none",
				on_keyup: true,
				//display_all_text: " [ Show all ] ",
				//sort_select: true,
				rows_counter: true,  
				rows_counter_text: "Registros: ",  
				//btn_reset: true
            };  
			var tf1 = setFilterGrid("lista_profesores",tabla_Props);
		}
	});
}

function agregaProfesor(fun){
	if( fun == 1 ){
		jQuery.ajax({
			type: "POST",
			url: "../php/cat_usuarios.php",
			data:{
				fun:2,
				fun2:1
			},
			beforeSend: function(){
				//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
			},
			fail: function(){
				//$.unblockUI();
				alert("Se perdi� la conexi�n...");
			},
			success: function(data, textStatus){
				$("#ap_content").html(data);
				$("#apmsj").hide();
				$("#imagen_log_prof_agre").hide();
				$("#aprof_modal").modal('show');
				$("#apcod").keyup(function() {
					if (this.value.match(/[^a-zA-Z0-9_]/g)) {
						this.value = this.value.replace(/[^a-zA-Z0-9_]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apnom").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#appat").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apmat").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apdir").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apcol").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apciu").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
			}
		});
	}else{
		limpiaMsjs();
		error=false
		if( !$("#apcod").val() ){
			error = true;
			$("#apcod_form").addClass("has-error");
		}
		if( !$("#apnom").val() ){
			error = true;
			$("#apnom_form").addClass("has-error");
		}
		if( !$("#appat").val() ){
			error = true;
			$("#appat_form").addClass("has-error");
		}
		if( !$("#apmat").val() ){
			error = true;
			$("#apmat_form").addClass("has-error");
		}
		if( !$("#fecnac").val() ){
			error = true;
			$("#apfecnac_form").addClass("has-error");
		}
		if( !$("#apdir").val() ){
			error = true;
			$("#apdir_form").addClass("has-error");
		}
		if( !$("#apcol").val() ){
			error = true;
			$("#apcol_form").addClass("has-error");
		}
		if( !$("#apciu").val() ){
			error = true;
			$("#apciu_form").addClass("has-error");
		}
		if( !$("#aptel").val()  || isNaN( parseInt( $("#aptel").val() )) ){
			error = true;
			$("#aptel_form").addClass("has-error");
		}
		if( $("#apgen").val() == 0 ){
			error = true;
			$("#apgen_form").addClass("has-error");
		}
		if( !$("#apmail").val() ){
			error = true;
			$("#apmail_form").addClass("has-error");
		}
		var filter = /[\w-\.]{3,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;
		if(!filter.test($("#apmail").val())){
			$("#apmail_form").addClass("has-error");
			error = true;
		}
		if(error){
			$("#apmsj").html('Debe llenar todos los datos correctamente.');
			$("#apmsj").slideDown();
		}else{
			jQuery.ajax({
				type: "POST",
				url: "../php/cat_usuarios.php",
				data:{
					fun:2,
					fun2:2,
					cod:$("#apcod").val(),
					nom:$("#apnom").val(),
					pat:$("#appat").val(),
					mat:$("#apmat").val(),
					fecnac:$("#fecnac").val(),
					dir:$("#apdir").val(),
					col:$("#apcol").val(),
					ciu:$("#apciu").val(),
					tel:$("#aptel").val(),
					gen:$("#apgen").val(),
					mail:$("#apmail").val()
				},
				beforeSend: function(){
					//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
					//$("#imagen_log_alum_agre").show();
				},
				fail: function(){
					//$.unblockUI();
					alert("Se perdi� la conexi�n...");
				},
				success: function(data, textStatus){
					$("#imagen_log_prof_agre").show();
					dat = data.split('@|');
					if( dat[0] == '1' ){
						$("#apmsj").html(dat[1]);
						$("#apmsj").slideDown();
						$("#imagen_log_prof_agre").hide();
						$("#apcod_form").addClass('has-error');
					}else
					if( dat[2] == '1' ){
						$("#apmsj").html(dat[3]);
						$("#apmsj").slideDown();
						$("#imagen_log_prof_agre").hide();
						$("#apmail_form").addClass('has-error');
					}else{
						$("#aprof_modal").modal('hide');
						listaProfesores();
					}
				}
			});
		}
	}
}

function modificarProfesor(fun, dat){
	if( fun == 1 ){
		jQuery.ajax({
			type: "POST",
			url: "../php/cat_usuarios.php",
			data:{
				fun:4,
				fun2:1,
				prof:dat
			},
			beforeSend: function(){
				//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
			},
			fail: function(){
				//$.unblockUI();
				alert("Se perdi� la conexi�n...");
			},
			success: function(data, textStatus){
				$("#ap_content1").html(data);
				$("#apmsjmod").hide();
				$("#imagen_log_prof_mod").hide();
				$("#aprof_modal_mod").modal('show');
				$("#apcod1").keyup(function() {
					if (this.value.match(/[^a-zA-Z0-9_]/g)) {
						this.value = this.value.replace(/[^a-zA-Z0-9_]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apnom1").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#appat1").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apmat1").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apdir1").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apcol1").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apciu1").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				var filter = /[\w-\.]{3,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;
				if(!filter.test($("#apmail1").val())){
					$("#apmail_form1").addClass("has-error");
					error = true;
				}
			}
		});
	}else{
		limpiaMsjs();
		error=false
		if( !$("#apcod1").val() ){
			error = true;
			$("#apcod_form1").addClass("has-error");
		}
		if( !$("#apnom1").val() ){
			error = true;
			$("#apnom_form1").addClass("has-error");
		}
		if( !$("#appat1").val() ){
			error = true;
			$("#appat_form1").addClass("has-error");
		}
		if( !$("#apmat1").val() ){
			error = true;
			$("#apmat_form1").addClass("has-error");
		}
		if( !$("#fecnac1").val() ){
			error = true;
			$("#apfecnac_form1").addClass("has-error");
		}
		if( !$("#apdir1").val() ){
			error = true;
			$("#apdir_form1").addClass("has-error");
		}
		if( !$("#apcol1").val() ){
			error = true;
			$("#apcol_form1").addClass("has-error");
		}
		if( !$("#apciu1").val() ){
			error = true;
			$("#apciu_form1").addClass("has-error");
		}
		if( !$("#aptel1").val()  || isNaN( parseInt( $("#aptel1").val() )) ){
			error = true;
			$("#aptel_form1").addClass("has-error");
		}
		if( $("#apgen1").val() == 0 ){
			error = true;
			$("#apgen_form1").addClass("has-error");
		}
		if( !$("#apmail1").val() ){
			error = true;
			$("#apmail_form1").addClass("has-error");
		}
		if( !$("#appass1").val() ){
			error = true;
			$("#appass_form1").addClass("has-error");
		}
		if(error){
			$("#apmsjmod").html('Debe llenar todos los datos correctamente.');
			$("#apmsjmod").slideDown();
		}else{
			jQuery.ajax({
				type: "POST",
				url: "../php/cat_usuarios.php",
				data:{
					fun:4,
					fun2:2,
					id:$("#apid1").val(),
					cod:$("#apcod1").val(),
					nom:$("#apnom1").val(),
					pat:$("#appat1").val(),
					mat:$("#apmat1").val(),
					fecnac:$("#fecnac1").val(),
					dir:$("#apdir1").val(),
					col:$("#apcol1").val(),
					ciu:$("#apciu1").val(),
					tel:$("#aptel1").val(),
					gen:$("#apgen1").val(),
					mail:$("#apmail1").val(),
					pass:$("#appass1").val()
				},
				beforeSend: function(){
					//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
				},
				fail: function(){
					//$.unblockUI();
					alert("Se perdi� la conexi�n...");
				},
				success: function(data, textStatus){
					$("#imagen_log_prof_mod").show();
					dat = data.split('@|');
					if( dat[0] == '1' ){
						$("#apmsjmod").html(dat[1]);
						$("#apmsjmod").slideDown();
						$("#imagen_log_prof_mod").hide();
						$("#apcod_form").addClass('has-error');
					}else
					if( dat[2] == '1' ){
						$("#apmsjmod").html(dat[3]);
						$("#apmsjmod").slideDown();
						$("#imagen_log_prof_mod").hide();
						$("#apmail_form").addClass('has-error');
					}else{
						$("#imagen_log_prof_mod").hide();
						$("#aprof_modal_mod").modal("hide");
						listaProfesores();
					}
				}
			});
		}
	}
}

function limpiaMsjs(){
	$("#apmsj").hide();
	$("#apmsjmod").hide();
	$("#imagen_log_prof_agre").hide();
	$("#imagen_log_prof_mod").hide()
	
	$("#apcod_form").removeClass("has-error");
	$("#appat_form").removeClass("has-error");
	$("#apmat_form").removeClass("has-error");
	$("#apnom_form").removeClass("has-error");
	$("#apfecnac_form").removeClass("has-error");
	$("#apdir_form").removeClass("has-error");
	$("#apcol_form").removeClass("has-error");
	$("#apciu_form").removeClass("has-error");
	$("#aptel_form").removeClass("has-error");
	$("#apgen_form").removeClass("has-error");
	$("#apmail_form").removeClass("has-error");
	
	$("#apcod_form1").removeClass("has-error");
	$("#appat_form1").removeClass("has-error");
	$("#apmat_form1").removeClass("has-error");
	$("#apnom_form1").removeClass("has-error");
	$("#apfecnac_form1").removeClass("has-error");
	$("#apdir_form1").removeClass("has-error");
	$("#apcol_form1").removeClass("has-error");
	$("#apciu_form1").removeClass("has-error");
	$("#aptel_form1").removeClass("has-error");
	$("#apgen_form1").removeClass("has-error");
	$("#apmail_form1").removeClass("has-error");
	$("#appass_form1").removeClass("has-error");
}

function infoProfesor(prof){
	jQuery.ajax({
		type: "POST",
		url: "../php/cat_usuarios.php",
		data:{
			fun:3,
			prof:prof
		},
		beforeSend: function(){
			//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
		},
		fail: function(){
			//$.unblockUI();
			alert("Se perdi� la conexi�n...");
		},
		success: function(data, textStatus){
			dat = data.split('@|');
			$("#profinfo_header").html(dat[0]);
			$("#prof_info").modal('show');
		}
	});
}