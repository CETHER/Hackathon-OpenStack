$(document).ready(function(){
	$("#contactForm").submit(false);
	$('#contactForm1')[0].reset();
	$('#contactForm2')[0].reset();
	$("#apmsj2").hide();
	$("#msj").hide();
	$("#imagen_log").hide();
	$("#imagen_log2").hide();
	$("#apcod_form").removeClass("has-error");
	$("#apnom_form").removeClass("has-error");
	$("#apgen_form").removeClass("has-error");	
	
	$("#msj_rec_pass_no").hide();
	$("#msj_rec_pass_ok").hide();
	$("#imagen_log1").hide();
});

function validar(){
	if( !$("#user").val() || !$("#pass").val()){
		$("#msj").html('Debe llenar todos los campos.');
		$("#msj").hide();
		$("#imagen_log").hide();
		$("#msj").fadeIn(500);
	}else{
		$("#msj").html('Validando datos...');
		var user = $("#user").val();
		var pass = $("#pass").val();
		$("#imagen_log").fadeIn();
		jQuery.ajax({
			type: "POST",
			url: "./php/login.php",
			data: {
				user:$("#user").val(),
				pass:$("#pass").val(),
				fun:1
			},
			beforeSend: function(){
				//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
				
			},
			fail: function(){
					//$.unblockUI();
					alert("Se perdi� la conexi�n...");
			},
			success: function(data, textStatus){
				$('#msj').html(data);
				//$("#msj").fadeOut(500);
				$("#msj").fadeIn(500);
				$("#imagen_log").hide();
				dat = data.split('|@');
				if( dat[0] == '0' ){
					$("#imagen_log").hide();
					$('#msj').html(dat[1]);
				}else{
					$("#imagen_log").hide();
					$('#msj').html(dat[1]);
					location.href="./html/main.php";
				}
			}
		});
	}
}

function rec_pass(){
	$("#msj_rec_pass_ok").fadeOut();
	$("#msj_rec_pass_no").fadeOut();
	
	if( !$("#prof").val() || !$("#correo").val()){
		$("#msj_rec_pass_no").html('Debe llenar todos los campos.');
		$("#imagen_log1").hide();
		$("#msj_rec_pass_no").fadeIn(500);
	}else{
		$("#msj_rec_pass_ok").html('Validando datos...');
		var prof = $("#prof").val();
		var correo = $("#correo").val();
		$("#imagen_log1").fadeIn();
		jQuery.ajax({
			type: "POST",
			url: "./php/login.php",
			data: {
				prof:$("#prof").val(),
				correo:$("#correo").val(),
				fun:5
			},
			beforeSend: function(){
			},
			fail: function(){
					alert("Se perdi� la conexi�n...");
			},
			success: function(data, textStatus){
				dat = data.split('|@');
				if( dat[0] == '0' ){
					$("#imagen_log1").hide();
					$("#msj_rec_pass_ok").fadeOut();
					$("#msj_rec_pass_no").fadeIn(300);
					$('#msj_rec_pass_no').html(dat[1]);	
				}else{
					$("#imagen_log1").hide();
					$("#msj_rec_pass_ok").fadeIn();
					$('#msj_rec_pass_ok').html(dat[1]);
					$("#msj_rec_pass_ok").fadeOut(5000);
					
					setTimeout(function(){$('#rec_pass').modal('hide');}, 5000);
					setTimeout(function(){
										$('#contactForm')[0].reset();
										$('#contactForm1')[0].reset();
										}, 5000);
					setTimeout(function(){$('#prof_info').modal('show');}, 5000);
			
					
				}
			}
		});
	}
}

function cancelar(){
	$('#contactForm')[0].reset();
	$('#contactForm1')[0].reset();
	$('#contactForm2')[0].reset();
	$("#msj").hide();
	$("#msj_rec_pass_no").hide();
	$("#msj_rec_pass_ok").hide();
	$("#imagen_log1").hide();
	$("#apmsj2").hide();
	$("#imagen_log2").hide();
}

