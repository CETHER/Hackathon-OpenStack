$(document).ready(function(){
	$("#salir").click(function(){
		jQuery.post("../php/login.php", {
			fun:2
			}, function(data, textStatus){
				location.href="../index.php";
			}
		);
	});
	listaProfesores();
});

function listaProfesores(){
	jQuery.ajax({
		type: "POST",
		url: "../subir_imagenes/examples/index.php",
		data:{
			user:$("#user_log").val()
		},
		beforeSend: function(){
			//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
		},
		fail: function(){
			//$.unblockUI();
			alert("Se perdi� la conexi�n...");
		},
		success: function(data, textStatus){
			$("#lista_profes").html(data);			
		}
	});
}

