$(document).ready(function(){
	$("#salir").click(function(){
		jQuery.post("../php/login.php", {
			fun:2
			}, function(data, textStatus){
				location.href="../index.php";
			}
		);
	});
	listaProfesores();
});

function listaProfesores(){
	jQuery.ajax({
		type: "POST",
		url: "../php/cat_admin.php",
		data:{
			fun:1
		},
		beforeSend: function(){
			//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
		},
		fail: function(){
			//$.unblockUI();
			alert("Se perdi� la conexi�n...");
		},
		success: function(data, textStatus){
			$("#lista_profes").html(data);
			var tabla_Props =  {   
				loader: true,
				loader_text: "Filtrando resultados...",
				help_instructions: false,
				btn_reset: true,
				col_0: "none",
				col_3: "none",
				on_keyup: true,
				//display_all_text: " [ Show all ] ",
				//sort_select: true,
				rows_counter: true,  
				rows_counter_text: "Registros: ",  
				//btn_reset: true
            };  
			var tf1 = setFilterGrid("lista_profesores",tabla_Props);
		}
	});
}

function agregaProfesor(fun){
	if( fun == 1 ){
		jQuery.ajax({
			type: "POST",
			url: "../php/cat_admin.php",
			data:{
				fun:2,
				fun2:1
			},
			beforeSend: function(){
				//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
			},
			fail: function(){
				//$.unblockUI();
				alert("Se perdi� la conexi�n...");
			},
			success: function(data, textStatus){
				$("#ap_content").html(data);
				$("#apmsj").hide();
				$("#imagen_log_prof_agre").hide();
				$("#aprof_modal").modal('show');
				$("#apcod").keyup(function() {
					if (this.value.match(/[^a-zA-Z0-9_]/g)) {
						this.value = this.value.replace(/[^a-zA-Z0-9_]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apnom").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
			}
		});
	}else{
		limpiaMsjs();
		error=false
		if( !$("#apcod").val() ){
			error = true;
			$("#apcod_form").addClass("has-error");
		}
		if( !$("#apnom").val() ){
			error = true;
			$("#apnom_form").addClass("has-error");
		}
		if( $("#apgen").val() == 0 ){
			error = true;
			$("#apgen_form").addClass("has-error");
		}
		if(error){
			$("#apmsj").html('Debe llenar todos los datos correctamente.');
			$("#apmsj").slideDown();
		}else{
			jQuery.ajax({
				type: "POST",
				url: "../php/cat_admin.php",
				data:{
					fun:2,
					fun2:2,
					cod:$("#apcod").val(),
					nom:$("#apnom").val(),
					gen:$("#apgen").val(),
				},
				beforeSend: function(){
					//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
					//$("#imagen_log_alum_agre").show();
				},
				fail: function(){
					//$.unblockUI();
					alert("Se perdi� la conexi�n...");
				},
				success: function(data, textStatus){
					$("#imagen_log_prof_agre").show();
					dat = data.split('@|');
					if( dat[0] == '1' ){
						$("#imagen_log_prof_agre").hide();
						$("#apmsj").html(dat[1]);
						$("#apmsj").slideDown();
						$("#apcod_form").addClass('has-error');
					}else
					    $("#aprof_modal").modal('hide');
						listaProfesores();
					}
			});
		}
	}
}

function modificarProfesor(fun, dat){
	if( fun == 1 ){
		jQuery.ajax({
			type: "POST",
			url: "../php/cat_admin.php",
			data:{
				fun:4,
				fun2:1,
				prof:dat
			},
			beforeSend: function(){
				//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
			},
			fail: function(){
				//$.unblockUI();
				alert("Se perdi� la conexi�n...");
			},
			success: function(data, textStatus){
				$("#ap_content1").html(data);
				$("#apmsjmod").hide();
				$("#imagen_log_prof_mod").hide();
				$("#aprof_modal_mod").modal('show');
				$("#apcod1").keyup(function() {
					if (this.value.match(/[^a-zA-Z0-9_]/g)) {
						this.value = this.value.replace(/[^a-zA-Z0-9_]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
				$("#apnom1").keyup(function() {
					if (this.value.match(/�[a-zA-Z ]/g)) {
						this.value = this.value.replace(/�[^a-zA-Z ]/g,'');
					}
					this.value=this.value.toUpperCase();
				});
			}
		});
	}else{
		limpiaMsjs();
		error=false
		if( !$("#apcod1").val() ){
			error = true;
			$("#apcod_form1").addClass("has-error");
		}
		if( !$("#apnom1").val() ){
			error = true;
			$("#apnom_form1").addClass("has-error");
		}
		if( !$("#appass1").val() ){
			error = true;
			$("#appass_form1").addClass("has-error");
		}
		if( $("#apgen1").val() == 0 ){
			error = true;
			$("#apgen_form1").addClass("has-error");
		}
		if(error){
			$("#apmsjmod").html('Debe llenar todos los datos correctamente.');
			$("#apmsjmod").slideDown();
		}else{
			jQuery.ajax({
				type: "POST",
				url: "../php/cat_admin.php",
				data:{
					fun:4,
					fun2:2,
					cod:$("#apcod1").val(),
					nom:$("#apnom1").val(),
					pass:$("#appass1").val(),
					gen:$("#apgen1").val(),
					id:$("#apid1").val(),
				},
				beforeSend: function(){
					//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
				},
				fail: function(){
					//$.unblockUI();
					alert("Se perdi� la conexi�n...");
				},
				success: function(data, textStatus){
					$("#imagen_log_prof_mod").show();
					dat = data.split('@|');
					if( dat[0] == '1' ){
						$("#imagen_log_prof_mod").hide();
						$("#apmsjmod").html(dat[1]);
						$("#apmsjmod").slideDown();
						$("#apcod_form").addClass('has-error');
					}else
					if( dat[2] == '1' ){
						$("#imagen_log_prof_mod").hide();
						$("#apmsjmod").html(dat[3]);
						$("#apmsjmod").slideDown();
						$("#apmail_form").addClass('has-error');
					}else{
						$("#aprof_modal_mod").modal("hide");
						listaProfesores();
					}
				}
			});
		}
	}
}

function limpiaMsjs(){
	$("#apmsj").hide();
	$("#apmsjmod").hide();
	$("#imagen_log_prof_agre").hide();
	$("#imagen_log_prof_mod").hide();
	$("#apcod_form").removeClass("has-error");
	$("#appat_form").removeClass("has-error");
	$("#apgen_form").removeClass("has-error");
	$("#apcod_form1").removeClass("has-error");
	$("#apnom_form1").removeClass("has-error");
	$("#appass_form1").removeClass("has-error");
	$("#apgen_form1").removeClass("has-error");
}

function infoProfesor(prof){
	jQuery.ajax({
		type: "POST",
		url: "../php/cat_admin.php",
		data:{
			fun:3,
			prof:prof
		},
		beforeSend: function(){
			//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
		},
		fail: function(){
			//$.unblockUI();
			alert("Se perdi� la conexi�n...");
		},
		success: function(data, textStatus){
			dat = data.split('@|');
			$("#profinfo_header").html(dat[0]);
			$("#prof_info").modal('show');
		}
	});
}