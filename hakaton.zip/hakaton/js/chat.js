jQuery(document).ready(function() {
		
	var janelas = new Array();
	
	function add_janelas(id, nome){
		var nom = nome.split('@');
		if(nom[0] == 1){var pref = 'PROF. ';}else{var pref = 'ALUM. ';}
		//jQuery('#pone_ventana_emociones').hide();
		// setInterval(function(){leido(id)}, 1000)   '+leido(id)+' 
		//<i class="fa fa-smile-o" style="text-align:center; margin-top:7px; margin-left:7px;"></i>
		var html_add = '<div class="janela" id="jan_'+id+'"><div class="topo" id="'+id+'" style="font-size:14px;" title="'+nom[1]+'"><span>'+pref+nom[1]+'</span><a href="javascript:void(0);" id="fechar" title="Cerrar"><i class="fa fa-close"></i></a></div><div id="corpo"><div class="mensagens"><ul class="listar"></ul><ul class="vist" style="font-size:10px; color:#999; text-align:center; "></ul><div class="muestra_caritas" id="pone_ventana_emociones_'+id+'">'+mostrar_img_emotions()+'</div><div class="muestra_caritas" id="pone_ventana_emociones_grandes_'+id+'">'+mostrar_img_emotions_grandes()+'</div><div class="extras" ><a href="javascript:void(0);" id="emot_'+id+'" class="emot" title="Emociones"><i class="fa fa-smile-o"></i></a><a href="javascript:void(0);" id="emot_grandes_'+id+'" class="emot_grandes" title="Emociones"><i class="fa fa-smile-o"></i></a></div></div><textarea rows="2" class="mensagem" id="mensagem_'+id+'" maxlength="255" placeholder="Escribe un mensaje"></textarea><a href="javascript:void(0);" id="btnn_enviar">Enviar</a></div></div>';
		jQuery('#janelas').append(html_add);
		actualizar_chats();
	}
	//abre chats	
	function abrir_janelas(x){
		jQuery('#contatos ul li a').each(function() {
           var link = jQuery(this);
		   var id = link.attr('id');
		   if(id == x){
		   		link.click();
				actualizar_chats();
		   }
        });
	}
	//enviar enter
	jQuery('body').delegate('.mensagem', 'keydown', function(e){
		var campo = jQuery(this);
		var mensagem = campo.val();
		var to = jQuery(this).attr('id');
		var de = jQuery('#user_log').val();
		var id = to.split('_');

		if(e.keyCode == 13){
			if(mensagem != ''){
				jQuery.post('../php/chat.php',{
					caso:'insertar',
					mensagem: mensagem,
					para: id[1],
					de:de
				}, function(retorno){
					jQuery('#jan_'+id[1]+' ul.listar').append(retorno);
					campo.val('');
					actualizar_chats();
				});
			}
		}
	});
	//enviar boton
	jQuery('a#btnn_enviar').live('click', 'keydown', function(e){
		var to = jQuery(this).parent().parent().attr('id');
		var de = jQuery('#user_log').val();
		var id = to.split('_');
		var campo = jQuery('#mensagem_'+id[1]);
		var mensagem = campo.val();

			if(mensagem != ''){
				jQuery.post('../php/chat.php',{
					caso:'insertar',
					mensagem: mensagem,
					para: id[1],
					de:de
				}, function(retorno){
					jQuery('#jan_'+id[1]+' ul.listar').append(retorno);
					campo.val('');
					actualizar_chats();
				});
			}else{
				alert('Escribe un mensaje');
			}
	});
	//verificar 
	function verificar_msgs(){	
		setInterval(function(){
		var user = jQuery('#user_log').val();
			jQuery.post('../php/chat.php',{
				caso:'verificar',
				user: user
			},function(x){
				if(x != ''){
					for(i in x){
						abrir_janelas(x[i]);
					}
				}else{}
			}, 'jSON');
		}, 1000);
	}
	verificar_msgs();
	//visto 
	jQuery('.mensagem').live('click', function(){
		var id = jQuery('.janela').children('.topo').attr('id');
		var session = jQuery('#user_log').val();
		
		jQuery.ajax({
			type: "POST",
			url: "../php/chat.php",
			data:{
				caso:'visto',user:id, session:session
			},
			fail: function(){
				alert("Se perdió la conexión...");
			},
			success: function(x){
				/*if(x == 1){
					//return jQuery("#algos").html(leido(id));
					//return jQuery('ul.vist').html(leido(id));
					actualizar_chats();
					//return jQuery('#jan_'+id+' ul.vist').html(leido(id));
					//alert(id);
					//leido(id);
					//alert('Algo');
					jQuery('#jan_'+session+' ul.vist').html(leido(id));
				}else{
					//jQuery("#algos").html(0);
					//return jQuery('ul.vist').html('Nada');
					//actualizar_chats();
					//return jQuery('#jan_'+id+' ul.vist').html(leido(id));
					alert('Nada');
				}
				jQuery('#jan_'+session+' ul.vist').html(leido(id));*/
			}
		});

		/*
		jQuery.post('../php/chat.php',{
			caso:'visto',user:id, session:session
		},function(x){
			if(x != ''){
				//return jQuery('#jan_'+i+' ul.vist').html(leido(id));
				return jQuery('ul.vist').html(leido(id));
			}else{
				//return jQuery('#jan_'+i+' ul.vist').html(leido(id));
				return jQuery('ul.vist').html('aaaaa');
			}
		}, 'jSON');
		*/
	});
	//abre chats automaticos
	jQuery('.comecar').live('click', function(){	
		var id = jQuery(this).attr('id');
		var nome = jQuery(this).attr('nome');
		janelas.push(id);
		
		for(var i = 0; i< janelas.length ; i++){
			if(janelas[i] == undefined ){
				janelas.splice(i, 1);
				i--;
			}else{
				actualizar_chats();
				add_janelas( id, nome );
				jQuery(this).removeClass('comecar');
				return false;
			}
		}
	});
	//Cierra las ventanas x	
	jQuery('a#fechar').live('click', function(){
		var id = jQuery(this).parent().attr('id');
		var user = jQuery('#user_log').val();
		var parent = jQuery(this).parent().parent().hide();
		jQuery('#contatos a#'+id+'').addClass('comecar');
			var n = janelas.length;
			for(i=0; i < n; i++){
				if(janelas[i] != undefined){
					if(janelas[i] == id){
						delete janelas[i];
					}
				}
			}
			
			jQuery.post('../php/chat.php',{
				caso:'posponer',
				session: user,
				user: id
			},function(x){
			});
	});
	// minimiza las ventanas
	jQuery('body').delegate('.topo', 'click', function(){
		var pai = jQuery(this).parent();
		var isto = jQuery(this);
		
		if(pai.children('#corpo').is(':hidden')){
			isto.removeClass('fixar');
			pai.children('#corpo').toggle();
		}else{
			isto.addClass('fixar');
			pai.children('#corpo').toggle();
		}
	});
	//actualiza chats
	function actualizar_chats(){
		var user = jQuery('#user_log').val();
		var id = jQuery('.janela').children('.topo').attr('id');

		jQuery.post('../php/chat.php',{
			caso:'actualizar',
			array: janelas,
			user: user
		},function(x){
			if(x != ''){
				for(i in x){
					jQuery('#jan_'+i+' ul.listar').html(x[i]).emoticons();
					jQuery('#jan_'+i+' ul.vist').html(leido(id));
					mostrar_mensajes_abajo();
				}
			}
		}, 'jSON');
		//actualiza numero de mensg nuevos 
		jQuery.ajax({
			type: "POST",
			url: "../php/chat.php",
			data:{
				caso:'actualiza_fun'
			},
			fail: function(){
				alert("Se perdió la conexión...");
			},
			success: function(dat){
				jQuery("#nuevos_mensaje_chat").html(dat);
			}
		});
	}
	//mostrar mensajes abajo
	function mostrar_mensajes_abajo(){	
		jQuery( ".listar" ).scrollTop( (jQuery( '.listar' ).height())*1000000);
	}
	//muestra mensaje visto
	function leido(id){
		var user = jQuery('#user_log').val();
		jQuery.post('../php/chat.php',{
			caso:'leido',
			user: id,
			session: user
		},function(x){
			if(x != ''){
				return jQuery('ul.vist').html(x);
			}else{
				return jQuery('ul.vist').html('');
			}
		}, 'jSON');
	}
	//abre la ventana de emociones chicas
	jQuery("a.emot").live('click', 'keydown', function(){		
		var dat = jQuery(this).parent().parent().parent().parent().attr('id');
		id = dat.split('_');
		jQuery('#pone_ventana_emociones_'+id[1]).toggle(1000);
    });
	//abre la ventana de emociones grandes
	jQuery("a.emot_grandes").live('click', 'keydown', function(){		
		var dat = jQuery(this).parent().parent().parent().parent().attr('id');
		id = dat.split('_');
		jQuery('#pone_ventana_emociones_grandes_'+id[1]).toggle(1000);
    });
	//trae las emociones del php	
	function mostrar_img_emotions(){
		return  jQuery('#emociones').html();
	}
	//trae las emociones grandes del php
	function mostrar_img_emotions_grandes(){
		return  jQuery('#emociones_grandes').html();
	}
	//envia las emociones chicas
	jQuery(".icono_chat").live('click', 'keydown', function(){		
		var dat = jQuery(this).parent().parent().parent().parent().parent().attr('id');
		id = dat.split('_');
		jQuery('#pone_ventana_emociones_'+id[1]).toggle();		
		
		var text = jQuery( '#mensagem_'+id[1] ).val();
		var dat_old = jQuery(this).parent().attr('id');
		var dat_new = text + dat_old ;
		jQuery( '#mensagem_'+id[1] ).val( dat_new );
    });
	//envia las emociones grandes
	jQuery(".icono_chat_grandes").live('click', 'keydown', function(){		
		var dat = jQuery(this).parent().parent().parent().parent().parent().attr('id');
		id = dat.split('_');
		jQuery('#pone_ventana_emociones_grandes_'+id[1]).toggle();
		
		var text = jQuery( '#mensagem_'+id[1] ).val();
		var dat_old = jQuery(this).parent().attr('id');
		var dat_new = text + dat_old ;
		jQuery( '#mensagem_'+id[1] ).val( dat_new );
    });

	
})
