jQuery.fn.emoticons = function(icon_folder) {
    /* emoticons is the folder where the emoticons are stored*/
    var icon_folder = icon_folder || "../imagenes/emotions";
    var emotes = {"smile": Array(":-)"), 
                  "sad": Array(":-("), 
                  "wink": Array(";)"), 
                  "grin": Array(":D"), 
                  "surprise": Array(":O"),
                  "devilish": Array("(6)"),
                  "angel": Array("(A)"),
                  "crying": Array(":,("), 
                  "plain": Array(":|"),
                  "smile-big": Array(":o)"),//10
				  
                  "glasses": Array("8)"), 
                  "kiss": Array("(K)"), 
                  "monkey": Array("(M)"),
				  "angry1": Array(":-O"),
				  "btn_emotion": Array(":-*"),
				  "happy": Array(":,-("),
				  "nice": Array("*)"),
				  "ooh": Array("=-O"),
				  "right": Array("{,2}"),
				  "sad1": Array(";-)"),//20
				  //nuevos
                  "angel2": Array(":¬["), 
                  "angry2": Array("8D"), 
                  "bandit": Array("BD="),
                  "bear": Array("=B="), 
                  "beer": Array("=BB="),
                  "bigsmile": Array("=bi"),
                  "bow": Array("=bw="), 
                  "brokenheart": Array(":!|"),
                  "bug": Array(";:)"),
                  "cake": Array(":8,)"), //30
				  
                  "call": Array("K))"), 
                  "cash": Array("(C)"),
				  "clapping": Array(":(O"),
				  "coffee": Array(":*C"),
				  "cool": Array("8-)"),
				  "cool2": Array("*_)"),
                  "crying2": Array(":°"), 
                  "dance": Array("*,)3"), 
                  "devil": Array("*,)4"),
                  "doh": Array("*,)5"),//40
				   
                  "drink": Array("*,)6"),
                  "drunk": Array("*,)7"),
                  "dull": Array("*,)8"), 
                  "eblush": Array("*,)9"),
                  "emo": Array("*,)0"),
                  "envy": Array(":[3"), 
                  "evilgrin": Array(":[4"), 
                  "flower": Array(":[5"),
				  "frown": Array(":[6"),
				  "fubar": Array(":[7"),//50
				  
                  "giggle": Array(":[8"),
                  "grin1": Array(":[9"),
                  "handshake": Array(":[0"), 
                  "happy2": Array(":]0"),
                  "headbang": Array(":]1"),
                  "heart": Array(":]2"), 
                  "heidy": Array(":]3"), 
                  "hi": Array(":]4"),
				  "inlove": Array(":]5"),
				  "itwasntme": Array(":]6"),//60
				  
				  "kiss2": Array(":]7"),
				  "lipssealed": Array(":]8"),
				  "mail": Array(":]9"),
				  "makeup": Array(";]0"),
				  "middlefinger": Array(";]1"),
				  "mmm": Array(";]2"),
				  "movie": Array(";]3"),
				  "muscle": Array(";]4"),
				  "music": Array(";]5"),
				  "myspace": Array(";]6"),//70
				  
				  "nerd": Array(",1,"),
				  "ninja": Array(",2,"),
				  "no": Array(",3,"),
				  "phone": Array(",4,"),
				  "nod": Array(",5,"),
				  "puke": Array(",6,"),
				  "polite_smile": Array(",7,"),
				  "pizza": Array(",8,"),
				  "_wink": Array(",9,"),
				  "party": Array(",0,"),//80
				  
				  "poolparty": Array(",,0"),
				  "rofl": Array(",,1"),
				  "rain": Array(",,2"),
				  "rock": Array(",,3"),
				  "punch": Array(",,4"),
				  "skepticism": Array(",,5"),
				  "smile2": Array(",,6"),
				  "sadsmile": Array(",,7"),
				  "sleepy": Array(",,8"),
				  "skype": Array(",,9"),//90
				  
				  "star": Array("0,,"),
				  "sweating": Array("1,,"),
				  "sarcasm": Array("2,,"),
				  "tmi": Array("3,,"),
				  "smoke": Array("4,,"),
				  "shake": Array("5,,"),
				  "surprised": Array("6,,"),
				  "sun": Array("7,,"),
				  "time": Array("8,,"),
				  "toivo": Array("9,,"),//100
				  
				  "smirk": Array("{.0}"),
				  "talking": Array("{.1}"),
				  "thinking": Array("{.2}"),
				  "swear": Array("{.3}"),
				  "speechless": Array("{.4}"),
				  "whew": Array("{.5}"),
				  "wait": Array("{.6}"),
				  "tongue": Array("{.7}"),
				  "tongueout": Array("{.8}"),
				  "worried": Array("{.9}"),//110
				  
				  "yes": Array(";]7"),
				  "wondering": Array(";]9"),
				  "yawn": Array("{,0}"),
				  //iconos mas grandes
				  "angry": Array("{,1}"),
				  "laughing": Array("=]"),
				  "smile1": Array("=)"),
				  "flushed": Array("=("),
				  "sunglasses": Array("=O"),
				  "neckbeard": Array(";°]"),
				  "1": Array("¬0"),
				  "2": Array("¬1"),
				  "3": Array("¬2"),
				  "4": Array("¬3"),
				  "5": Array("¬4"),
				  "6": Array("¬5"),
				  "7": Array("¬6"),
				  "8": Array("¬7"),
				  "9": Array("¬8"),
				  "10": Array("¬9"),
				  
				  "11": Array("Ð°0"),
				  "12": Array("Ð1"),
				  "13": Array("Ð2"),
				  "14": Array("Ð3"),
				  "15": Array("Ð4"),
				  "16": Array("Ð5"),
				  "17": Array("Ð6"),
				  "18": Array("Ð7"),
				  "19": Array("Ð8"),
				  "20": Array("Ð9"),
				  "21": Array("°0"),
				  "22": Array("°1"),
				  "23": Array("°2"),
				  "24": Array("°3"),
				  
				  };
                  
    function emoticons(html){
        for(var emoticon in emotes){
            for(var i = 0; i < emotes[emoticon].length; i++){
                html = html.replace(emotes[emoticon][i],"<img src=\""+icon_folder+"/face-"+emoticon+".png\" class=\"emoticonimg\" alt=\""+emotes[emoticon][i]+"\"/>","g");
            }
        }
        return html;
    }
    return this.each(function(){
        jQuery(this).html(emoticons(jQuery(this).html()));
    });
};